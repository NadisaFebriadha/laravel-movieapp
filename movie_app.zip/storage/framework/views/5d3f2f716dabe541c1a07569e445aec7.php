

<?php $__env->startSection('content'); ?>
<h2 class="text-2xl font-bold mb-6">Edit Movie: <?php echo e($movie->judul); ?></h2>

<form action="<?php echo e(route('movies.update', $movie)); ?>" method="POST" enctype="multipart/form-data" class="bg-gray-800 p-6 rounded-xl">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
            <label class="block mb-1">Judul</label>
            <input type="text" name="judul" value="<?php echo e($movie->judul); ?>" class="w-full p-2 rounded bg-gray-700 text-white" required>
        </div>
        <div>
            <label class="block mb-1">Genre</label>
            <input type="text" name="genre" value="<?php echo e($movie->genre); ?>" class="w-full p-2 rounded bg-gray-700 text-white">
        </div>
        <div>
            <label class="block mb-1">Tahun Rilis</label>
            <input type="number" name="release_year" value="<?php echo e($movie->release_year); ?>" class="w-full p-2 rounded bg-gray-700 text-white">
        </div>
        <div>
            <label class="block mb-1">Rating</label>
            <input type="text" name="rating" value="<?php echo e($movie->rating); ?>" class="w-full p-2 rounded bg-gray-700 text-white">
        </div>
        <div>
            <label class="block mb-1">Season</label>
            <input type="text" name="season" value="<?php echo e($movie->season); ?>" class="w-full p-2 rounded bg-gray-700 text-white">
        </div>
        <div>
            <label class="block mb-1">Episode</label>
            <input type="text" name="episode" value="<?php echo e($movie->episode); ?>" class="w-full p-2 rounded bg-gray-700 text-white">
        </div>
    </div>
    <div class="mt-4">
        <label class="block mb-1">Deskripsi</label>
        <textarea name="deskripsi" rows="4" class="w-full p-2 rounded bg-gray-700 text-white"><?php echo e($movie->deskripsi); ?></textarea>
    </div>
    <div class="mt-4">
        <label class="block mb-1">Gambar Saat Ini</label>
        <?php if($movie->gambar): ?>
            <img src="<?php echo e(asset('storage/' . $movie->gambar)); ?>" class="w-32 h-32 object-cover rounded mb-2">
        <?php endif; ?>
        <input type="file" name="gambar" class="text-white">
    </div>
    <div class="mt-6 text-right">
        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded">Update</button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dev\movie_app\resources\views/movies/edit.blade.php ENDPATH**/ ?>